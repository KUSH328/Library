-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 24, 2023 at 11:08 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `greysense`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `book_id` int(100) NOT NULL,
  `user_id` int(100) DEFAULT NULL,
  `genre` varchar(300) NOT NULL,
  `title` varchar(300) NOT NULL,
  `author` varchar(300) NOT NULL,
  `publisher` varchar(300) NOT NULL,
  `edition` int(100) NOT NULL,
  `isbn` varchar(100) NOT NULL,
  `pages` int(100) NOT NULL,
  `date_issued` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`book_id`, `user_id`, `genre`, `title`, `author`, `publisher`, `edition`, `isbn`, `pages`, `date_issued`) VALUES
(1, 5, 'Horror', 'Salems Lot', 'Stephen King', 'Creepy Publications', 3, '56453425673', 800, '2022-07-10'),
(3, 4, 'Adventure', 'Into the Wild', 'Jon Krakauer', 'Nat Geo Publications', 8, '89764534256', 1200, '2022-07-11'),
(4, 5, 'Adventure', 'Moby-Dick', 'Herman Melville', 'CYOA Publications', 1, '89764534215', 667, '2022-07-10'),
(5, 2, 'Adventure', 'Harry Potter & The Deadly Hallows', 'J.K Rowling', 'Rowling''s Publications', 2, '90876564321', 798, '2022-07-10'),
(7, 0, 'Mystery', 'One by One', 'Ruth Ware', 'Harville Publications', 2, '90875645321', 669, '2022-01-10'),
(10, 0, 'Modern Literature', 'In a Station of the Metro', 'Ezra Pound', 'NY Publishers', 8, '89765534521', 4215, '2022-07-11');

-- --------------------------------------------------------

--
-- Table structure for table `books_request`
--

CREATE TABLE `books_request` (
  `request_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `genre` varchar(300) NOT NULL,
  `title` varchar(300) NOT NULL,
  `author` varchar(300) NOT NULL,
  `edition` int(10) NOT NULL,
  `isbn` varchar(100) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books_request`
--

INSERT INTO `books_request` (`request_id`, `user_id`, `genre`, `title`, `author`, `edition`, `isbn`, `date`) VALUES
(1, 2, 'Mystery', 'End of Watch', 'Stephen King', 3, '12365676317', '2022-11-10'),
(2, 5, 'Mystery', 'Finders Keepers', 'Stephen King', 3, '49747656345', '2022-11-10'),
(3, 4, 'Mystery', 'The Outsider ', 'Stephen King', 3, '67452341563', '2022-11-13');

-- --------------------------------------------------------

--
-- Table structure for table `issue_date`
--

CREATE TABLE `issue_date` (
  `issue_id` int(10) NOT NULL,
  `book_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `issue_date`
--

INSERT INTO `issue_date` (`issue_id`, `book_id`, `user_id`, `date`) VALUES
(1, 1, 2, '2022-07-10'),
(2, 5, 2, '2021-07-10'),
(3, 3, 2, '2021-07-10'),
(4, 4, 5, '2022-07-10'),
(5, 1, 2, '2022-07-10'),
(6, 5, 5, '2022-07-10'),
(7, 1, 5, '2021-07-10'),
(8, 4, 5, '2022-07-10'),
(9, 3, 5, '2022-07-10'),
(10, 5, 5, '2022-07-10'),
(11, 3, 5, '2022-07-10'),
(12, 3, 5, '2022-07-10'),
(13, 3, 5, '2022-07-10'),
(14, 3, 5, '2022-07-10'),
(15, 3, 4, '2022-07-10'),
(16, 1, 5, '2022-07-10'),
(17, 3, 5, '2022-07-10'),
(18, 5, 2, '2022-07-10'),
(19, 3, 4, '2022-07-11'),
(20, 7, 4, '2022-07-11'),
(21, 7, 5, '2023-01-11'),
(22, 3, 4, '2023-01-11');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(100) NOT NULL,
  `name` varchar(300) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `email` varchar(300) NOT NULL,
  `is_admin` tinyint(1) NOT NULL,
  `password` varchar(300) NOT NULL,
  `address` varchar(300) NOT NULL,
  `gender` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `phone`, `email`, `is_admin`, `password`, `address`, `gender`) VALUES
(1, 'Jamal Adan', '14478653467', 'adminjamal@gmail.com', 1, 'admin1234', 'Streetville Dubai', 'Male'),
(2, 'Angie Rose', '9867564323', 'angierose@gmail.com', 0, 'angie1234', 'Hawai 13', 'Female'),
(4, 'Raphael Jonnes', '8756245431', 'raphjonnes@outlook.com', 0, 'raphael1234', 'Ampur 13, Dhaka', 'Male'),
(5, 'Sophia Grant', '9876542345', 'sophie560@gmail.com', 0, 'sophie1234', 'Vitara, Sector 10', 'Female'),
(6, 'Jeniffer Haman', '78563425690', 'jenhamman@gmail.com', 0, 'jeniffer000', 'Bahamas, Corner Bell', 'Female'),
(7, 'Isaac Dennis', '5648783423', 'isaacdennis1@gmail.com', 0, 'isaac1234', 'Barley Road', 'Male'),
(8, 'Fatuma Mohammed', '5678345623', 'fatuma34@gmail.com', 0, 'fatuma1234', 'Villa 12, Doha', 'Male');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`book_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `books_request`
--
ALTER TABLE `books_request`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `issue_date`
--
ALTER TABLE `issue_date`
  ADD PRIMARY KEY (`issue_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `book_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `books_request`
--
ALTER TABLE `books_request`
  MODIFY `request_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `issue_date`
--
ALTER TABLE `issue_date`
  MODIFY `issue_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
